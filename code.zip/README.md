ApartmentSerbiaBot - Бот для поиска квартир в Сербии. Создается для обучения.

Для разработки:
https://github.com/eternnoir/pyTelegramBotAPI/blob/master/examples/step_example.py

https://emojipedia.org/

zip -r sources.zip .